<?php
  include(dirname(__DIR__).'/includes/header.php');
?>
<main id="main">
  <div class="content">
    <h1 class="construction title">This page is currently under construction</h1>
  </div>
</main>
<?php
  include(dirname(__DIR__).'/includes/footer.php');
?>
