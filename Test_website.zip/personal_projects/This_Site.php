<?php
  include(dirname(__DIR__).'/includes/header.php');
?>
<div id="main">
    <div class="content">
        <h1 class="title">This site</h1>
        <div class="center-text">
            <p>This site was originally made for a school project I was doing at the time.</p>
            <p>
                After working on it for a couple of hours I decide that I wanted to make a site where I could
                display the projects I've done.
            </p>
        </div>
    </div>
</div>
<?php
  include(dirname(__DIR__).'/includes/footer.php');
?>
