<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <meta property="og:title" content="">
    <meta property="og:type" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
  
    <link rel="manifest" href="site.webmanifest">
    <link rel="apple-touch-icon" href="icon.png">
    <!-- Place favicon.ico in the root directory -->

    <link rel="stylesheet" href="\My_Website\css\normalize.css">
    <link rel="stylesheet" href="\My_Website\css\main.css">
    <link rel="stylesheet" href="\My_Website\css\custom.css">
    <link rel="stylesheet" href="\My_Website\css\navbar.css">
    <link rel="stylesheet" href="\My_Website\css\footer.css">
    <link rel="stylesheet" href="\My_Website\css\fonts.css">
    <link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous"> -->
    <meta name="theme-color" content="#fafafa">
  </head>
  <body>