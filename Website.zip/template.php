<?php
  include(dirname(__DIR__).'/includes/header.php');
?>

<div id="main">
  <div class="content">

  </div>
</div>

<?php
  include(dirname(__DIR__).'/includes/footer.php');
?>
