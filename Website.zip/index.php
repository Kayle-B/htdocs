<?php
  include(__DIR__.'/includes/header.php');
?>
<div id="main">
  <div class="content">
      <h1 class="title">Welcome!</h1>
      <div class="center-text">
        <p>This text is mainly ment to fill up the home page :)</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo eligendi laudantium placeat aut, facere assumenda, repellendus sed, animi quasi quidem expedita quisquam. Commodi suscipit ducimus ullam optio debitis minima nulla.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem molestias aliquam magni atque nihil modi inventore doloremque, dolore provident harum dicta perferendis tempore quo repellat illo, culpa cum iste. Molestiae! </p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio expedita excepturi aliquam tenetur neque blanditiis repudiandae deserunt itaque quam asperiores porro iste quaerat consequatur quos, pariatur aut doloremque est quas!</p>
      </div>
  </div>
</div>
<?php
  include(__DIR__.'/includes/footer.php');
?>
 